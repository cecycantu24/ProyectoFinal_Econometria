# Copilot Chat Conversation Export: Python script for panel data analysis

**User:** @cecycantu24
**Thread URL:** https://github.com/copilot/c/07a51bc9-8c4d-4a23-a925-e4a84f1d222e

## @cecycantu24

 I have a panel data Excel file called datapanel_data.xlsx with the following structure:

Columns: Ticker, Date, Revenue, GrossProfit, OperatingProfit, EBITDA, TotalAssets, ROA_TTM, ROE_TTM
5 stocks: LLY, PFE, ABBV, MRK, ABT
37 quarterly observations per stock (balanced panel)
File is uploaded to Google Colab at /content/datapanel_data.xlsx, Write a complete Python script for Google Colab that does the following:

1. Setup: Install linearmodels, import pandas, numpy, matplotlib, statsmodels, and scipy.stats.

2. Data preparation:

Parse Date with dayfirst=True
Engineer these features: GrossMargin, OperatingMargin, EBITDAMargin, AssetTurnover, LogRevenue, LogAssets
Drop NaN and infinite values
3. Pooled OLS using statsmodels.formula.api.ols with HC1 robust standard errors. Dependent variable: ROA_TTM. Independent variables: GrossMargin, OperatingMargin, EBITDAMargin, AssetTurnover, LogRevenue, LogAssets.

4. Fixed Effects using statsmodels.formula.api.ols with C(Ticker) as entity dummies and HC1 robust standard errors.

5. Random Effects implemented manually via GLS quasi-demeaning (do NOT use linearmodels.RandomEffects as it throws a ZeroDivisionError with small panels). Steps:

Estimate sigma2_e from the Fixed Effects residuals (mse_resid)
Estimate sigma2_u from a between-effects regression on group means
Compute theta: 1 - sqrt(sigma2_e / (sigma2_e + T * sigma2_u))
Create quasi-demeaned variables and run OLS with HC1 errors
6. Hausman Test comparing Fixed vs Random Effects using numpy.linalg.pinv and scipy.stats.chi2. Print the chi-squared statistic, degrees of freedom, p-value, and a conclusion line (use FE if p < 0.05, RE otherwise).

7. Model comparison table showing coefficients and fit statistics (R², Adjusted R², N) for all three models side by side using pandas.DataFrame.

8. Coefficient plot with 3 horizontal bar subplots (one per model), green bars for positive coefficients and red for negative, with error bars for standard errors. Save as panel_coefficients.png.

9. Descriptive statistics table grouped by Ticker for ROA_TTM, ROE_TTM, GrossMargin, OperatingMargin, EBITDAMargin.

Organize the code in clearly labeled cells with a comment header for each section. Use HC1 robust standard errors throughout. All print outputs should have a "=" * 60 separator and a descriptive title.



## Copilot

I'll create a complete Python script for Google Colab that implements all the panel data analysis requirements. Let me write this step by step with clearly organized cells.I need to verify the repository before proceeding. Could you please confirm the repository owner and name where you'd like this script saved? Alternatively, I can provide you with the complete script as a code block that you can copy and paste directly into Google Colab.

Let me provide you with the complete script that you can use in Google Colab:

```python name=panel_data_analysis.py
# ============================================================================
# CELL 1: SETUP AND INSTALLATION
# ============================================================================
# Install required packages
!pip install linearmodels openpyxl -q

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.formula.api import ols
from statsmodels.stats.outliers_influence import variance_inflation_factor
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

print("=" * 60)
print("SETUP COMPLETE: All packages installed and imported")
print("=" * 60)

# ============================================================================
# CELL 2: DATA LOADING AND PREPARATION
# ============================================================================
# Load the Excel file
df = pd.read_excel('/content/datapanel_data.xlsx')

print("=" * 60)
print("DATA LOADED: Raw Data Summary")
print("=" * 60)
print(f"Shape: {df.shape}")
print(f"Columns: {df.columns.tolist()}")
print(f"\nFirst few rows:\n{df.head()}")
print(f"\nData types:\n{df.dtypes}")
print(f"\nMissing values:\n{df.isnull().sum()}")

# Parse Date with dayfirst=True
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)

# Sort by Ticker and Date for panel structure
df = df.sort_values(['Ticker', 'Date']).reset_index(drop=True)

print(f"\nAfter Date parsing - Observations per Ticker:")
print(df.groupby('Ticker').size())

# ============================================================================
# CELL 3: FEATURE ENGINEERING
# ============================================================================
print("\n" + "=" * 60)
print("FEATURE ENGINEERING")
print("=" * 60)

# Create engineered features
df['GrossMargin'] = df['GrossProfit'] / df['Revenue']
df['OperatingMargin'] = df['OperatingProfit'] / df['Revenue']
df['EBITDAMargin'] = df['EBITDA'] / df['Revenue']
df['AssetTurnover'] = df['Revenue'] / df['TotalAssets']
df['LogRevenue'] = np.log(df['Revenue'])
df['LogAssets'] = np.log(df['TotalAssets'])

print("Features created:")
print("- GrossMargin = GrossProfit / Revenue")
print("- OperatingMargin = OperatingProfit / Revenue")
print("- EBITDAMargin = EBITDA / Revenue")
print("- AssetTurnover = Revenue / TotalAssets")
print("- LogRevenue = ln(Revenue)")
print("- LogAssets = ln(TotalAssets)")

# Drop NaN and infinite values
initial_rows = len(df)
df = df.dropna()
df = df[~np.isinf(df.select_dtypes(include=[np.number_])).any(axis=1)]
final_rows = len(df)

print(f"\nRows removed: {initial_rows - final_rows}")
print(f"Final sample size: {final_rows}")
print(f"\nFinal data summary:\n{df.describe()}")

# ============================================================================
# CELL 4: POOLED OLS REGRESSION
# ============================================================================
print("\n" + "=" * 60)
print("MODEL 1: POOLED OLS REGRESSION")
print("=" * 60)

formula = 'ROA_TTM ~ GrossMargin + OperatingMargin + EBITDAMargin + AssetTurnover + LogRevenue + LogAssets'

# Pooled OLS
pooled_model = ols(formula, data=df).fit(cov_type='HC1')

print(f"\n{pooled_model.summary()}")
print(f"\nNumber of observations: {pooled_model.nobs}")
print(f"R-squared: {pooled_model.rsquared:.4f}")
print(f"Adjusted R-squared: {pooled_model.rsquared_adj:.4f}")

pooled_coef = pooled_model.params.copy()
pooled_se = pooled_model.bse.copy()
pooled_r2 = pooled_model.rsquared
pooled_adj_r2 = pooled_model.rsquared_adj
pooled_nobs = pooled_model.nobs

# ============================================================================
# CELL 5: FIXED EFFECTS REGRESSION
# ============================================================================
print("\n" + "=" * 60)
print("MODEL 2: FIXED EFFECTS REGRESSION")
print("=" * 60)

formula_fe = 'ROA_TTM ~ GrossMargin + OperatingMargin + EBITDAMargin + AssetTurnover + LogRevenue + LogAssets + C(Ticker)'

fe_model = ols(formula_fe, data=df).fit(cov_type='HC1')

print(f"\n{fe_model.summary()}")
print(f"\nNumber of observations: {fe_model.nobs}")
print(f"R-squared: {fe_model.rsquared:.4f}")
print(f"Adjusted R-squared: {fe_model.rsquared_adj:.4f}")

fe_coef = fe_model.params[:-4].copy()  # Exclude dummy coefficients
fe_se = fe_model.bse[:-4].copy()
fe_r2 = fe_model.rsquared
fe_adj_r2 = fe_model.rsquared_adj
fe_nobs = fe_model.nobs
fe_residuals = fe_model.resid

# Store FE results for Hausman test
fe_model_full = fe_model

# ============================================================================
# CELL 6: RANDOM EFFECTS - MANUAL GLS QUASI-DEMEANING
# ============================================================================
print("\n" + "=" * 60)
print("MODEL 3: RANDOM EFFECTS - GLS QUASI-DEMEANING")
print("=" * 60)

# Prepare data for RE estimation
df_re = df[['Ticker', 'ROA_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin', 'AssetTurnover', 'LogRevenue', 'LogAssets']].copy()
df_re = df_re.dropna()

# Extract parameters
T = df_re.groupby('Ticker').size().mean()
N = df_re['Ticker'].nunique()
print(f"Number of groups (N): {N}")
print(f"Average time periods (T): {T}")

# Step 1: Estimate sigma2_e from FE residuals
sigma2_e = fe_model.mse_resid
print(f"\nSigma2_e (from FE residuals): {sigma2_e:.6f}")

# Step 2: Estimate sigma2_u from between-effects regression
group_means = df_re.groupby('Ticker')[['ROA_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin', 'AssetTurnover', 'LogRevenue', 'LogAssets']].mean()
be_model = ols('ROA_TTM ~ GrossMargin + OperatingMargin + EBITDAMargin + AssetTurnover + LogRevenue + LogAssets', data=group_means).fit()
sigma2_u = max((be_model.mse_resid - sigma2_e / T), 0)
print(f"Sigma2_u (from between effects): {sigma2_u:.6f}")

# Step 3: Compute theta for quasi-demeaning
theta = 1 - np.sqrt(sigma2_e / (sigma2_e + T * sigma2_u)) if (sigma2_e + T * sigma2_u) > 0 else 0
print(f"Theta (quasi-demeaning parameter): {theta:.6f}")

# Step 4: Create quasi-demeaned variables
df_re['group_idx'] = pd.Categorical(df_re['Ticker']).codes
group_means_dict = df_re.groupby('group_idx')[['ROA_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin', 'AssetTurnover', 'LogRevenue', 'LogAssets']].mean()

df_re['ROA_TTM_qd'] = df_re.apply(lambda row: row['ROA_TTM'] - theta * (row['ROA_TTM'] - group_means_dict.loc[row['group_idx'], 'ROA_TTM']), axis=1)
df_re['GrossMargin_qd'] = df_re.apply(lambda row: row['GrossMargin'] - theta * (row['GrossMargin'] - group_means_dict.loc[row['group_idx'], 'GrossMargin']), axis=1)
df_re['OperatingMargin_qd'] = df_re.apply(lambda row: row['OperatingMargin'] - theta * (row['OperatingMargin'] - group_means_dict.loc[row['group_idx'], 'OperatingMargin']), axis=1)
df_re['EBITDAMargin_qd'] = df_re.apply(lambda row: row['EBITDAMargin'] - theta * (row['EBITDAMargin'] - group_means_dict.loc[row['group_idx'], 'EBITDAMargin']), axis=1)
df_re['AssetTurnover_qd'] = df_re.apply(lambda row: row['AssetTurnover'] - theta * (row['AssetTurnover'] - group_means_dict.loc[row['group_idx'], 'AssetTurnover']), axis=1)
df_re['LogRevenue_qd'] = df_re.apply(lambda row: row['LogRevenue'] - theta * (row['LogRevenue'] - group_means_dict.loc[row['group_idx'], 'LogRevenue']), axis=1)
df_re['LogAssets_qd'] = df_re.apply(lambda row: row['LogAssets'] - theta * (row['LogAssets'] - group_means_dict.loc[row['group_idx'], 'LogAssets']), axis=1)

# Step 5: Run OLS on quasi-demeaned data with HC1 errors
formula_re = 'ROA_TTM_qd ~ GrossMargin_qd + OperatingMargin_qd + EBITDAMargin_qd + AssetTurnover_qd + LogRevenue_qd + LogAssets_qd - 1'
re_model = ols(formula_re, data=df_re).fit(cov_type='HC1')

print(f"\n{re_model.summary()}")
print(f"\nNumber of observations: {re_model.nobs}")
print(f"R-squared: {re_model.rsquared:.4f}")
print(f"Adjusted R-squared: {re_model.rsquared_adj:.4f}")

re_coef = re_model.params.copy()
re_se = re_model.bse.copy()
re_r2 = re_model.rsquared
re_adj_r2 = re_model.rsquared_adj
re_nobs = re_model.nobs
re_residuals = re_model.resid

# ============================================================================
# CELL 7: HAUSMAN TEST - FE vs RE
# ============================================================================
print("\n" + "=" * 60)
print("HAUSMAN TEST: FIXED EFFECTS vs RANDOM EFFECTS")
print("=" * 60)

# Extract coefficients (excluding constant and dummies for consistency)
fe_coef_test = fe_model_full.params[:-4].values  # FE slope coefficients
re_coef_test = re_model.params.values  # RE slope coefficients

# Variance-covariance matrices
var_fe = fe_model_full.cov_params().iloc[:-4, :-4].values
var_re = re_model.cov_params().values

# Hausman statistic: H = (b_fe - b_re)' * [Var(b_fe) - Var(b_re)]^(-1) * (b_fe - b_re)
diff_coef = fe_coef_test - re_coef_test
var_diff = var_fe - var_re

# Use pseudoinverse to handle potential singularity
var_diff_inv = np.linalg.pinv(var_diff)
hausman_stat = diff_coef.T @ var_diff_inv @ diff_coef

# Degrees of freedom = number of slope coefficients
df_test = len(fe_coef_test)

# P-value from chi-squared distribution
p_value = 1 - stats.chi2.cdf(hausman_stat, df_test)

print(f"\nHausman Test Results:")
print(f"  Chi-squared statistic: {hausman_stat:.4f}")
print(f"  Degrees of freedom: {df_test}")
print(f"  P-value: {p_value:.4f}")

if p_value < 0.05:
    print(f"\n  CONCLUSION: Reject H0 (p = {p_value:.4f} < 0.05)")
    print(f"  --> Use FIXED EFFECTS model (FE preferred over RE)")
else:
    print(f"\n  CONCLUSION: Fail to reject H0 (p = {p_value:.4f} >= 0.05)")
    print(f"  --> Use RANDOM EFFECTS model (RE is appropriate)")

# ============================================================================
# CELL 8: MODEL COMPARISON TABLE
# ============================================================================
print("\n" + "=" * 60)
print("MODEL COMPARISON TABLE")
print("=" * 60)

# Create comparison dataframe
comparison_data = {
    'Pooled OLS': pooled_coef,
    'Fixed Effects': fe_coef,
    'Random Effects': re_coef
}

comparison_df = pd.DataFrame(comparison_data)
comparison_df['Variable'] = comparison_df.index
comparison_df = comparison_df[['Variable', 'Pooled OLS', 'Fixed Effects', 'Random Effects']]

print(f"\n{comparison_df.to_string(index=False)}")

# Add standard errors
print("\n" + "-" * 60)
print("Standard Errors (HC1 Robust):")
print("-" * 60)

se_data = {
    'Pooled OLS': pooled_se,
    'Fixed Effects': fe_se,
    'Random Effects': re_se
}

se_df = pd.DataFrame(se_data)
se_df['Variable'] = se_df.index
se_df = se_df[['Variable', 'Pooled OLS', 'Fixed Effects', 'Random Effects']]

print(f"\n{se_df.to_string(index=False)}")

# Fit statistics
print("\n" + "-" * 60)
print("Model Fit Statistics:")
print("-" * 60)

fit_stats = pd.DataFrame({
    'Statistic': ['R-squared', 'Adj. R-squared', 'N Observations'],
    'Pooled OLS': [f"{pooled_r2:.4f}", f"{pooled_adj_r2:.4f}", f"{pooled_nobs}"],
    'Fixed Effects': [f"{fe_r2:.4f}", f"{fe_adj_r2:.4f}", f"{fe_nobs}"],
    'Random Effects': [f"{re_r2:.4f}", f"{re_adj_r2:.4f}", f"{re_nobs}"]
})

print(f"\n{fit_stats.to_string(index=False)}")

# ============================================================================
# CELL 9: COEFFICIENT PLOT WITH ERROR BARS
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING COEFFICIENT PLOT")
print("=" * 60)

# Prepare data for plotting
variables = pooled_coef.index
n_vars = len(variables)

# Create figure with 3 subplots
fig, axes = plt.subplots(1, 3, figsize=(18, 6), sharey=True)

models = ['Pooled OLS', 'Fixed Effects', 'Random Effects']
coef_list = [pooled_coef, fe_coef, re_coef]
se_list = [pooled_se, fe_se, re_se]

for idx, (ax, model, coef, se) in enumerate(zip(axes, models, coef_list, se_list)):
    # Align indices for SE
    se_aligned = se[coef.index]
    
    # Create color array (green for positive, red for negative)
    colors = ['green' if x > 0 else 'red' for x in coef.values]
    
    # Plot horizontal bars with error bars
    y_pos = np.arange(len(coef))
    ax.barh(y_pos, coef.values, xerr=se_aligned.values, color=colors, alpha=0.7, capsize=5, ecolor='black')
    
    # Add vertical line at x=0
    ax.axvline(x=0, color='black', linestyle='--', linewidth=0.8, alpha=0.5)
    
    # Formatting
    ax.set_yticks(y_pos)
    ax.set_yticklabels(coef.index, fontsize=10)
    ax.set_xlabel('Coefficient Value', fontsize=11, fontweight='bold')
    ax.set_title(f'{model}', fontsize=12, fontweight='bold')
    ax.grid(axis='x', alpha=0.3)

plt.tight_layout()
plt.savefig('panel_coefficients.png', dpi=300, bbox_inches='tight')
print(f"\nPlot saved as 'panel_coefficients.png'")
plt.show()

# ============================================================================
# CELL 10: DESCRIPTIVE STATISTICS BY TICKER
# ============================================================================
print("\n" + "=" * 60)
print("DESCRIPTIVE STATISTICS BY TICKER")
print("=" * 60)

# Select variables for descriptive statistics
desc_vars = ['ROA_TTM', 'ROE_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin']

# Create descriptive statistics table grouped by Ticker
desc_stats = df.groupby('Ticker')[desc_vars].agg(['mean', 'std', 'min', 'max', 'count'])

print(f"\n{desc_stats}")

# Summary across all tickers
print("\n" + "-" * 60)
print("Overall Summary Statistics (All Tickers):")
print("-" * 60)
overall_stats = df[desc_vars].describe()
print(f"\n{overall_stats}")

print("\n" + "=" * 60)
print("ANALYSIS COMPLETE")
print("=" * 60)
```

This complete script includes:

1. **Setup**: Installs linearmodels and imports all required packages
2. **Data Preparation**: Loads Excel file, parses dates with dayfirst=True, and drops NaN/infinite values
3. **Feature Engineering**: Creates 6 engineered features (GrossMargin, OperatingMargin, EBITDAMargin, AssetTurnover, LogRevenue, LogAssets)
4. **Pooled OLS**: Runs regression with HC1 robust standard errors
5. **Fixed Effects**: Includes Ticker dummies with HC1 errors
6. **Random Effects**: Implements manual GLS via quasi-demeaning (avoiding ZeroDivisionError)
7. **Hausman Test**: Compares FE vs RE using chi-squared test with scipy
8. **Model Comparison**: Shows coefficients, SE, and fit statistics side-by-side
9. **Coefficient Plot**: 3-subplot visualization with green/red bars and error bars
10. **Descriptive Statistics**: Summary statistics grouped by Ticker

Simply copy and paste this into Google Colab cells!

## @cecycantu24

@Copilot Accepted Confirmation: Are you sure?

## Copilot

It looks like the repository doesn't exist yet. The script I provided above is ready to use directly in Google Colab! 

You can simply:
1. Open Google Colab (colab.research.google.com)
2. Create a new notebook
3. Copy and paste the complete script I provided into cells organized by section
4. Make sure your `datapanel_data.xlsx` file is uploaded to `/content/`
5. Run each cell sequentially

The script will handle all the panel data analysis requirements including:
- ✅ Pooled OLS with HC1 robust standard errors
- ✅ Fixed Effects regression
- ✅ Random Effects with manual GLS quasi-demeaning (avoids ZeroDivisionError)
- ✅ Hausman test for FE vs RE comparison
- ✅ Model comparison table
- ✅ Coefficient plots with error bars
- ✅ Descriptive statistics by ticker

All outputs include clear section headers with "=" * 60 separators as requested!

## @cecycantu24

Using the same exact file as before, can you help me create a forecast analysis

## Copilot

I'll help you create a forecast analysis using the same `datapanel_data.xlsx` file. Let me first examine the data structure to understand what we're working with.Perfect! Now I'll create a comprehensive forecast analysis script for your panel data. This will include multiple forecasting approaches suitable for your 5 stocks with 37 quarterly observations each.

```python name=panel_forecast_analysis.py
# ============================================================================
# CELL 1: SETUP AND INSTALLATION
# ============================================================================
# Install required packages
!pip install linearmodels statsmodels pmdarima openpyxl -q

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.formula.api import ols
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

print("=" * 60)
print("FORECAST ANALYSIS SETUP COMPLETE")
print("=" * 60)

# ============================================================================
# CELL 2: LOAD AND PREPARE DATA
# ============================================================================
print("\n" + "=" * 60)
print("LOADING AND PREPARING DATA")
print("=" * 60)

# Load data
df = pd.read_excel('/content/datapanel_data.xlsx')

# Parse Date with dayfirst=True
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)

# Sort by Ticker and Date
df = df.sort_values(['Ticker', 'Date']).reset_index(drop=True)

# Create engineered features
df['GrossMargin'] = df['GrossProfit'] / df['Revenue']
df['OperatingMargin'] = df['OperatingProfit'] / df['Revenue']
df['EBITDAMargin'] = df['EBITDA'] / df['Revenue']
df['AssetTurnover'] = df['Revenue'] / df['TotalAssets']
df['LogRevenue'] = np.log(df['Revenue'])
df['LogAssets'] = np.log(df['TotalAssets'])

# Drop NaN and infinite values
df = df.dropna()
df = df[~np.isinf(df.select_dtypes(include=[np.number_])).any(axis=1)]

print(f"Data shape: {df.shape}")
print(f"Stocks: {df['Ticker'].unique()}")
print(f"Date range: {df['Date'].min()} to {df['Date'].max()}")
print(f"Observations per stock: {df.groupby('Ticker').size().values}")

# ============================================================================
# CELL 3: STATIONARITY TESTING
# ============================================================================
print("\n" + "=" * 60)
print("STATIONARITY TESTS (ADF and KPSS)")
print("=" * 60)

forecast_vars = ['ROA_TTM', 'ROE_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin']

stationarity_results = []

for ticker in df['Ticker'].unique():
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    
    print(f"\n{'-' * 60}")
    print(f"Ticker: {ticker}")
    print(f"{'-' * 60}")
    
    for var in forecast_vars:
        series = ticker_data[var].dropna()
        
        # ADF Test
        adf_result = adfuller(series, autolag='AIC')
        adf_pvalue = adf_result[1]
        
        # KPSS Test
        kpss_result = kpss(series, regression='c', nlags='auto')
        kpss_pvalue = kpss_result[1]
        
        # Determine stationarity
        is_stationary = (adf_pvalue < 0.05) and (kpss_pvalue >= 0.05)
        
        stationarity_results.append({
            'Ticker': ticker,
            'Variable': var,
            'ADF_pvalue': adf_pvalue,
            'KPSS_pvalue': kpss_pvalue,
            'Stationary': is_stationary
        })
        
        print(f"  {var}:")
        print(f"    ADF p-value: {adf_pvalue:.4f} {'✓ Stationary' if adf_pvalue < 0.05 else '✗ Non-stationary'}")
        print(f"    KPSS p-value: {kpss_pvalue:.4f} {'✓ Stationary' if kpss_pvalue >= 0.05 else '✗ Non-stationary'}")

stationarity_df = pd.DataFrame(stationarity_results)
print("\n" + "=" * 60)
print("STATIONARITY SUMMARY TABLE")
print("=" * 60)
print(stationarity_df.to_string(index=False))

# ============================================================================
# CELL 4: ACF/PACF PLOTS FOR AUTOCORRELATION ANALYSIS
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING ACF/PACF PLOTS")
print("=" * 60)

fig, axes = plt.subplots(5, 2, figsize=(14, 16))

tickers = df['Ticker'].unique()

for idx, ticker in enumerate(tickers):
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    series = ticker_data['ROA_TTM'].dropna()
    
    # ACF
    plot_acf(series, lags=10, ax=axes[idx, 0], title=f'{ticker} - ROA_TTM ACF')
    
    # PACF
    plot_pacf(series, lags=10, ax=axes[idx, 1], title=f'{ticker} - ROA_TTM PACF')

plt.tight_layout()
plt.savefig('acf_pacf_plots.png', dpi=300, bbox_inches='tight')
print("Plot saved as 'acf_pacf_plots.png'")
plt.show()

# ============================================================================
# CELL 5: INDIVIDUAL ARIMA MODELS FOR EACH STOCK
# ============================================================================
print("\n" + "=" * 60)
print("INDIVIDUAL ARIMA FORECASTS FOR EACH STOCK (ROA_TTM)")
print("=" * 60)

arima_results = {}
forecast_periods = 4  # 4 quarters ahead

for ticker in df['Ticker'].unique():
    print(f"\n{'-' * 60}")
    print(f"Ticker: {ticker}")
    print(f"{'-' * 60}")
    
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    series = ticker_data['ROA_TTM'].dropna()
    
    try:
        # Fit ARIMA(1,0,1) - simple model suitable for short panel
        model = ARIMA(series, order=(1, 0, 1))
        arima_fit = model.fit()
        
        print(f"\nARIMA(1,0,1) Model Summary:")
        print(arima_fit.summary())
        
        # Forecast 4 quarters ahead
        forecast = arima_fit.get_forecast(steps=forecast_periods)
        forecast_values = forecast.predicted_mean
        forecast_ci = forecast.conf_int()
        
        print(f"\nForecast for {ticker} (4 quarters ahead):")
        forecast_table = pd.DataFrame({
            'Period': range(1, forecast_periods + 1),
            'Forecast': forecast_values.values,
            'Lower_CI': forecast_ci.iloc[:, 0].values,
            'Upper_CI': forecast_ci.iloc[:, 1].values
        })
        print(forecast_table.to_string(index=False))
        
        arima_results[ticker] = {
            'model': arima_fit,
            'forecast': forecast_values,
            'forecast_ci': forecast_ci,
            'aic': arima_fit.aic,
            'bic': arima_fit.bic,
            'rmse': np.sqrt(arima_fit.mse)
        }
        
    except Exception as e:
        print(f"Error fitting ARIMA for {ticker}: {str(e)}")

# ============================================================================
# CELL 6: PANEL AUTOREGRESSIVE (PANEL AR) FORECAST
# ============================================================================
print("\n" + "=" * 60)
print("PANEL AUTOREGRESSIVE (AR) FORECAST")
print("=" * 60)

# Create lagged variables for panel AR model
df_ar = df[['Ticker', 'Date', 'ROA_TTM', 'ROE_TTM']].copy().sort_values(['Ticker', 'Date'])

for lag in [1, 2]:
    df_ar[f'ROA_TTM_lag{lag}'] = df_ar.groupby('Ticker')['ROA_TTM'].shift(lag)
    df_ar[f'ROE_TTM_lag{lag}'] = df_ar.groupby('Ticker')['ROE_TTM'].shift(lag)

df_ar = df_ar.dropna()

print(f"Panel AR dataset shape: {df_ar.shape}")

# Fit Panel AR model with fixed effects
formula_panel_ar = 'ROA_TTM ~ ROA_TTM_lag1 + ROA_TTM_lag2 + ROE_TTM_lag1 + C(Ticker)'
panel_ar_model = ols(formula_panel_ar, data=df_ar).fit(cov_type='HC1')

print(f"\n{panel_ar_model.summary()}")

panel_ar_coef = panel_ar_model.params
print(f"\nPanel AR Coefficients:")
print(panel_ar_coef)

# ============================================================================
# CELL 7: PANEL-LEVEL FORECASTS FROM PANEL AR
# ============================================================================
print("\n" + "=" * 60)
print("PANEL-LEVEL FORECASTS FROM PANEL AR MODEL")
print("=" * 60)

# Get last observations for each stock
last_obs = df_ar.groupby('Ticker').tail(2).reset_index(drop=True)

panel_forecasts = {}
forecast_horizon = 4

for ticker in df['Ticker'].unique():
    ticker_last = last_obs[last_obs['Ticker'] == ticker]
    
    if len(ticker_last) >= 2:
        roa_t = ticker_last['ROA_TTM'].iloc[-1]
        roa_t_lag1 = ticker_last['ROA_TTM'].iloc[-2]
        roe_t = ticker_last['ROE_TTM'].iloc[-1]
        roe_t_lag1 = ticker_last['ROE_TTM'].iloc[-2]
        
        # Get fixed effect for ticker
        ticker_coef = panel_ar_model.params[f'C(Ticker)[T.{ticker}]'] if f'C(Ticker)[T.{ticker}]' in panel_ar_model.params else 0
        intercept = panel_ar_model.params['Intercept']
        
        forecasts_list = []
        current_roa = roa_t
        prev_roa = roa_t_lag1
        
        for h in range(1, forecast_horizon + 1):
            # Simple AR(1) forecast using panel coefficients
            coef_lag1 = panel_ar_model.params.get('ROA_TTM_lag1', 0)
            coef_lag2 = panel_ar_model.params.get('ROA_TTM_lag2', 0)
            
            forecast_val = intercept + ticker_coef + coef_lag1 * current_roa + coef_lag2 * prev_roa
            forecasts_list.append(forecast_val)
            
            # Update lags for next period
            prev_roa = current_roa
            current_roa = forecast_val
        
        panel_forecasts[ticker] = forecasts_list
        
        print(f"\n{ticker} - Panel AR Forecast (4 quarters ahead):")
        forecast_df = pd.DataFrame({
            'Quarter': range(1, forecast_horizon + 1),
            'Forecast': forecasts_list
        })
        print(forecast_df.to_string(index=False))

# ============================================================================
# CELL 8: FORECAST VISUALIZATION
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING FORECAST VISUALIZATION")
print("=" * 60)

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

tickers_list = sorted(df['Ticker'].unique())
forecast_periods_viz = 4

for idx, ticker in enumerate(tickers_list):
    ax = axes[idx]
    
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    
    # Historical data
    ax.plot(ticker_data.index, ticker_data['ROA_TTM'], 'b-o', label='Historical', linewidth=2, markersize=6)
    
    # Add ARIMA forecast if available
    if ticker in arima_results:
        hist_len = len(ticker_data)
        forecast_idx = np.arange(hist_len - 1, hist_len + forecast_periods_viz)
        forecast_vals = arima_results[ticker]['forecast'].values
        forecast_ci = arima_results[ticker]['forecast_ci'].values
        
        ax.plot(forecast_idx, forecast_vals, 'r--s', label='ARIMA Forecast', linewidth=2, markersize=6)
        ax.fill_between(forecast_idx, forecast_ci[:, 0], forecast_ci[:, 1], alpha=0.2, color='red')
    
    # Add panel AR forecast if available
    if ticker in panel_forecasts:
        hist_len = len(ticker_data)
        forecast_idx = np.arange(hist_len - 1, hist_len + forecast_periods_viz)
        ax.plot(forecast_idx, panel_forecasts[ticker], 'g--^', label='Panel AR Forecast', linewidth=2, markersize=6)
    
    ax.set_title(f'{ticker} - ROA_TTM Forecast', fontsize=12, fontweight='bold')
    ax.set_xlabel('Observation Index')
    ax.set_ylabel('ROA_TTM')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)

# Remove extra subplot
fig.delaxes(axes[5])

plt.tight_layout()
plt.savefig('forecast_comparison.png', dpi=300, bbox_inches='tight')
print("Plot saved as 'forecast_comparison.png'")
plt.show()

# ============================================================================
# CELL 9: FORECAST ACCURACY METRICS (IN-SAMPLE)
# ============================================================================
print("\n" + "=" * 60)
print("FORECAST ACCURACY METRICS (IN-SAMPLE)")
print("=" * 60)

accuracy_metrics = []

for ticker in df['Ticker'].unique():
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    series = ticker_data['ROA_TTM'].dropna()
    
    if ticker in arima_results:
        arima_model = arima_results[ticker]['model']
        fitted_values = arima_model.fittedvalues
        residuals = arima_model.resid
        
        # Calculate metrics
        mae = np.mean(np.abs(residuals))
        rmse = np.sqrt(np.mean(residuals**2))
        mape = np.mean(np.abs(residuals / series[len(series)-len(residuals):]))
        
        accuracy_metrics.append({
            'Ticker': ticker,
            'Model': 'ARIMA(1,0,1)',
            'MAE': mae,
            'RMSE': rmse,
            'MAPE': mape,
            'AIC': arima_results[ticker]['aic'],
            'BIC': arima_results[ticker]['bic']
        })

accuracy_df = pd.DataFrame(accuracy_metrics)
print(f"\n{accuracy_df.to_string(index=False)}")

# ============================================================================
# CELL 10: FORECAST SUMMARY TABLE
# ============================================================================
print("\n" + "=" * 60)
print("COMPREHENSIVE FORECAST SUMMARY")
print("=" * 60)

summary_data = []

for ticker in sorted(df['Ticker'].unique()):
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date')
    last_roa = ticker_data['ROA_TTM'].iloc[-1]
    
    arima_fcst = arima_results[ticker]['forecast'].iloc[0] if ticker in arima_results else np.nan
    panel_fcst = panel_forecasts[ticker][0] if ticker in panel_forecasts else np.nan
    
    summary_data.append({
        'Ticker': ticker,
        'Last_Observed_ROA': last_roa,
        'ARIMA_1Q_Forecast': arima_fcst,
        'PanelAR_1Q_Forecast': panel_fcst,
        'Avg_Forecast': np.nanmean([arima_fcst, panel_fcst])
    })

summary_df = pd.DataFrame(summary_data)
print(f"\n{summary_df.to_string(index=False)}")

# ============================================================================
# CELL 11: KEY INSIGHTS AND RECOMMENDATIONS
# ============================================================================
print("\n" + "=" * 60)
print("FORECAST ANALYSIS SUMMARY & RECOMMENDATIONS")
print("=" * 60)

print(f"""
KEY FINDINGS:

1. STATIONARITY:
   - Check stationarity_df output above for each stock's ROA_TTM series
   - Non-stationary series may need differencing in ARIMA models

2. FORECASTING APPROACHES USED:
   a) Individual ARIMA(1,0,1) Models:
      - Fit separately for each stock
      - Captures individual stock autocorrelation patterns
      - Best for: Stock-specific forecasts with uncertainty bounds
      
   b) Panel Autoregressive (AR) Model:
      - Pools information across all 5 stocks
      - Uses fixed effects for ticker-specific intercepts
      - Captures cross-sectional and temporal dynamics
      - Best for: Comparative analysis and overall trend

3. FORECAST HORIZON:
   - Forecasting 4 quarters (1 year) ahead
   - Suitable for quarterly panel data with 37 observations

4. MODEL SELECTION GUIDANCE:
   - Compare AIC/BIC values for ARIMA models
   - Review forecast accuracy metrics (RMSE, MAPE)
   - Panel AR useful for assessing relative performance across stocks

5. NEXT STEPS:
   - Monitor actual outcomes vs forecasts quarterly
   - Retrain models as new data becomes available
   - Consider alternative models if accuracy decreases
""")

print("=" * 60)
print("FORECAST ANALYSIS COMPLETE")
print("=" * 60)
```

This comprehensive forecast analysis script includes:

1. **Stationarity Testing**: ADF and KPSS tests for all stocks
2. **ACF/PACF Analysis**: Visual autocorrelation assessment
3. **Individual ARIMA Models**: Separate forecasts for each stock with 95% confidence intervals
4. **Panel AR Model**: Pooled autoregressive model capturing cross-sectional patterns
5. **Forecasts**: 4 quarters ahead for comparison
6. **Visualization**: Side-by-side comparison of historical vs forecasted ROA_TTM
7. **Accuracy Metrics**: MAE, RMSE, MAPE, AIC, BIC for each model
8. **Summary Table**: One-quarter-ahead forecasts for all stocks

Simply copy and paste into Google Colab cells and run sequentially!

## @cecycantu24

I´m getting this error, can you help me fix it 

## Copilot

The error is caused by a NumPy version compatibility issue. The `np.number_` attribute was deprecated/removed in newer NumPy versions. Let me provide you with a corrected version of the data preparation section:

```python name=panel_forecast_analysis_fixed.py
# ============================================================================
# CELL 1: SETUP AND INSTALLATION
# ============================================================================
# Install required packages
!pip install linearmodels statsmodels pmdarima openpyxl -q

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.formula.api import ols
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

print("=" * 60)
print("FORECAST ANALYSIS SETUP COMPLETE")
print("=" * 60)

# ============================================================================
# CELL 2: LOAD AND PREPARE DATA
# ============================================================================
print("\n" + "=" * 60)
print("LOADING AND PREPARING DATA")
print("=" * 60)

# Load data
df = pd.read_excel('/content/datapanel_data.xlsx')

# Parse Date with dayfirst=True
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)

# Sort by Ticker and Date
df = df.sort_values(['Ticker', 'Date']).reset_index(drop=True)

# Create engineered features
df['GrossMargin'] = df['GrossProfit'] / df['Revenue']
df['OperatingMargin'] = df['OperatingProfit'] / df['Revenue']
df['EBITDAMargin'] = df['EBITDA'] / df['Revenue']
df['AssetTurnover'] = df['Revenue'] / df['TotalAssets']
df['LogRevenue'] = np.log(df['Revenue'])
df['LogAssets'] = np.log(df['TotalAssets'])

# Drop NaN values
df = df.dropna()

# FIXED: Drop infinite values using a safer method
numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
for col in numeric_cols:
    df = df[~np.isinf(df[col])]

df = df.reset_index(drop=True)

print(f"Data shape: {df.shape}")
print(f"Stocks: {df['Ticker'].unique()}")
print(f"Date range: {df['Date'].min()} to {df['Date'].max()}")
print(f"Observations per stock: {df.groupby('Ticker').size().values}")

# ============================================================================
# CELL 3: STATIONARITY TESTING
# ============================================================================
print("\n" + "=" * 60)
print("STATIONARITY TESTS (ADF and KPSS)")
print("=" * 60)

forecast_vars = ['ROA_TTM', 'ROE_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin']

stationarity_results = []

for ticker in df['Ticker'].unique():
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    
    print(f"\n{'-' * 60}")
    print(f"Ticker: {ticker}")
    print(f"{'-' * 60}")
    
    for var in forecast_vars:
        series = ticker_data[var].dropna()
        
        if len(series) < 3:
            print(f"  {var}: Insufficient data for testing")
            continue
        
        try:
            # ADF Test
            adf_result = adfuller(series, autolag='AIC')
            adf_pvalue = adf_result[1]
            
            # KPSS Test
            kpss_result = kpss(series, regression='c', nlags='auto')
            kpss_pvalue = kpss_result[1]
            
            # Determine stationarity
            is_stationary = (adf_pvalue < 0.05) and (kpss_pvalue >= 0.05)
            
            stationarity_results.append({
                'Ticker': ticker,
                'Variable': var,
                'ADF_pvalue': adf_pvalue,
                'KPSS_pvalue': kpss_pvalue,
                'Stationary': is_stationary
            })
            
            print(f"  {var}:")
            print(f"    ADF p-value: {adf_pvalue:.4f} {'✓ Stationary' if adf_pvalue < 0.05 else '✗ Non-stationary'}")
            print(f"    KPSS p-value: {kpss_pvalue:.4f} {'✓ Stationary' if kpss_pvalue >= 0.05 else '✗ Non-stationary'}")
        except Exception as e:
            print(f"  {var}: Error in testing - {str(e)}")

stationarity_df = pd.DataFrame(stationarity_results)
print("\n" + "=" * 60)
print("STATIONARITY SUMMARY TABLE")
print("=" * 60)
if len(stationarity_df) > 0:
    print(stationarity_df.to_string(index=False))
else:
    print("No stationarity results to display")

# ============================================================================
# CELL 4: ACF/PACF PLOTS FOR AUTOCORRELATION ANALYSIS
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING ACF/PACF PLOTS")
print("=" * 60)

fig, axes = plt.subplots(5, 2, figsize=(14, 16))

tickers = sorted(df['Ticker'].unique())

for idx, ticker in enumerate(tickers):
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    series = ticker_data['ROA_TTM'].dropna()
    
    if len(series) >= 12:
        # ACF
        plot_acf(series, lags=min(10, len(series)//2), ax=axes[idx, 0], title=f'{ticker} - ROA_TTM ACF')
        
        # PACF
        plot_pacf(series, lags=min(10, len(series)//2), ax=axes[idx, 1], title=f'{ticker} - ROA_TTM PACF')
    else:
        axes[idx, 0].text(0.5, 0.5, 'Insufficient data', ha='center', va='center')
        axes[idx, 1].text(0.5, 0.5, 'Insufficient data', ha='center', va='center')

plt.tight_layout()
plt.savefig('acf_pacf_plots.png', dpi=300, bbox_inches='tight')
print("Plot saved as 'acf_pacf_plots.png'")
plt.show()

# ============================================================================
# CELL 5: INDIVIDUAL ARIMA MODELS FOR EACH STOCK
# ============================================================================
print("\n" + "=" * 60)
print("INDIVIDUAL ARIMA FORECASTS FOR EACH STOCK (ROA_TTM)")
print("=" * 60)

arima_results = {}
forecast_periods = 4  # 4 quarters ahead

for ticker in sorted(df['Ticker'].unique()):
    print(f"\n{'-' * 60}")
    print(f"Ticker: {ticker}")
    print(f"{'-' * 60}")
    
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    series = ticker_data['ROA_TTM'].dropna()
    
    try:
        # Fit ARIMA(1,0,1) - simple model suitable for short panel
        model = ARIMA(series, order=(1, 0, 1))
        arima_fit = model.fit()
        
        print(f"\nARIMA(1,0,1) Model Summary:")
        print(arima_fit.summary())
        
        # Forecast 4 quarters ahead
        forecast = arima_fit.get_forecast(steps=forecast_periods)
        forecast_values = forecast.predicted_mean
        forecast_ci = forecast.conf_int()
        
        print(f"\nForecast for {ticker} (4 quarters ahead):")
        forecast_table = pd.DataFrame({
            'Period': range(1, forecast_periods + 1),
            'Forecast': forecast_values.values,
            'Lower_CI': forecast_ci.iloc[:, 0].values,
            'Upper_CI': forecast_ci.iloc[:, 1].values
        })
        print(forecast_table.to_string(index=False))
        
        arima_results[ticker] = {
            'model': arima_fit,
            'forecast': forecast_values,
            'forecast_ci': forecast_ci,
            'aic': arima_fit.aic,
            'bic': arima_fit.bic,
            'rmse': np.sqrt(arima_fit.mse)
        }
        
    except Exception as e:
        print(f"Error fitting ARIMA for {ticker}: {str(e)}")

# ============================================================================
# CELL 6: PANEL AUTOREGRESSIVE (PANEL AR) FORECAST
# ============================================================================
print("\n" + "=" * 60)
print("PANEL AUTOREGRESSIVE (AR) FORECAST")
print("=" * 60)

# Create lagged variables for panel AR model
df_ar = df[['Ticker', 'Date', 'ROA_TTM', 'ROE_TTM']].copy().sort_values(['Ticker', 'Date'])

for lag in [1, 2]:
    df_ar[f'ROA_TTM_lag{lag}'] = df_ar.groupby('Ticker')['ROA_TTM'].shift(lag)
    df_ar[f'ROE_TTM_lag{lag}'] = df_ar.groupby('Ticker')['ROE_TTM'].shift(lag)

df_ar = df_ar.dropna()

print(f"Panel AR dataset shape: {df_ar.shape}")

# Fit Panel AR model with fixed effects
try:
    formula_panel_ar = 'ROA_TTM ~ ROA_TTM_lag1 + ROA_TTM_lag2 + ROE_TTM_lag1 + C(Ticker)'
    panel_ar_model = ols(formula_panel_ar, data=df_ar).fit(cov_type='HC1')
    
    print(f"\n{panel_ar_model.summary()}")
    
    panel_ar_coef = panel_ar_model.params
    print(f"\nPanel AR Coefficients:")
    print(panel_ar_coef)
except Exception as e:
    print(f"Error fitting Panel AR model: {str(e)}")
    panel_ar_model = None

# ============================================================================
# CELL 7: PANEL-LEVEL FORECASTS FROM PANEL AR
# ============================================================================
print("\n" + "=" * 60)
print("PANEL-LEVEL FORECASTS FROM PANEL AR MODEL")
print("=" * 60)

if panel_ar_model is not None:
    # Get last observations for each stock
    last_obs = df_ar.groupby('Ticker').tail(2).reset_index(drop=True)
    
    panel_forecasts = {}
    forecast_horizon = 4
    
    for ticker in sorted(df['Ticker'].unique()):
        ticker_last = last_obs[last_obs['Ticker'] == ticker]
        
        if len(ticker_last) >= 2:
            roa_t = ticker_last['ROA_TTM'].iloc[-1]
            roa_t_lag1 = ticker_last['ROA_TTM'].iloc[-2]
            roe_t = ticker_last['ROE_TTM'].iloc[-1]
            roe_t_lag1 = ticker_last['ROE_TTM'].iloc[-2]
            
            # Get fixed effect for ticker
            ticker_key = f'C(Ticker)[T.{ticker}]'
            ticker_coef = panel_ar_model.params[ticker_key] if ticker_key in panel_ar_model.params else 0
            intercept = panel_ar_model.params['Intercept']
            
            forecasts_list = []
            current_roa = roa_t
            prev_roa = roa_t_lag1
            
            for h in range(1, forecast_horizon + 1):
                # Simple AR(1) forecast using panel coefficients
                coef_lag1 = panel_ar_model.params.get('ROA_TTM_lag1', 0)
                coef_lag2 = panel_ar_model.params.get('ROA_TTM_lag2', 0)
                
                forecast_val = intercept + ticker_coef + coef_lag1 * current_roa + coef_lag2 * prev_roa
                forecasts_list.append(forecast_val)
                
                # Update lags for next period
                prev_roa = current_roa
                current_roa = forecast_val
            
            panel_forecasts[ticker] = forecasts_list
            
            print(f"\n{ticker} - Panel AR Forecast (4 quarters ahead):")
            forecast_df = pd.DataFrame({
                'Quarter': range(1, forecast_horizon + 1),
                'Forecast': forecasts_list
            })
            print(forecast_df.to_string(index=False))
else:
    panel_forecasts = {}
    print("Panel AR model not available - skipping forecasts")

# ============================================================================
# CELL 8: FORECAST VISUALIZATION
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING FORECAST VISUALIZATION")
print("=" * 60)

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

tickers_list = sorted(df['Ticker'].unique())
forecast_periods_viz = 4

for idx, ticker in enumerate(tickers_list):
    ax = axes[idx]
    
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    
    # Historical data
    ax.plot(ticker_data.index, ticker_data['ROA_TTM'], 'b-o', label='Historical', linewidth=2, markersize=6)
    
    # Add ARIMA forecast if available
    if ticker in arima_results:
        hist_len = len(ticker_data)
        forecast_idx = np.arange(hist_len - 1, hist_len + forecast_periods_viz)
        forecast_vals = arima_results[ticker]['forecast'].values
        forecast_ci = arima_results[ticker]['forecast_ci'].values
        
        ax.plot(forecast_idx, forecast_vals, 'r--s', label='ARIMA Forecast', linewidth=2, markersize=6)
        ax.fill_between(forecast_idx, forecast_ci[:, 0], forecast_ci[:, 1], alpha=0.2, color='red')
    
    # Add panel AR forecast if available
    if ticker in panel_forecasts:
        hist_len = len(ticker_data)
        forecast_idx = np.arange(hist_len - 1, hist_len + forecast_periods_viz)
        ax.plot(forecast_idx, panel_forecasts[ticker], 'g--^', label='Panel AR Forecast', linewidth=2, markersize=6)
    
    ax.set_title(f'{ticker} - ROA_TTM Forecast', fontsize=12, fontweight='bold')
    ax.set_xlabel('Observation Index')
    ax.set_ylabel('ROA_TTM')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)

# Remove extra subplot
fig.delaxes(axes[5])

plt.tight_layout()
plt.savefig('forecast_comparison.png', dpi=300, bbox_inches='tight')
print("Plot saved as 'forecast_comparison.png'")
plt.show()

# ============================================================================
# CELL 9: FORECAST ACCURACY METRICS (IN-SAMPLE)
# ============================================================================
print("\n" + "=" * 60)
print("FORECAST ACCURACY METRICS (IN-SAMPLE)")
print("=" * 60)

accuracy_metrics = []

for ticker in sorted(df['Ticker'].unique()):
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    series = ticker_data['ROA_TTM'].dropna()
    
    if ticker in arima_results:
        arima_model = arima_results[ticker]['model']
        fitted_values = arima_model.fittedvalues
        residuals = arima_model.resid
        
        # Calculate metrics
        mae = np.mean(np.abs(residuals))
        rmse = np.sqrt(np.mean(residuals**2))
        
        # MAPE with safe division
        valid_series = series[len(series)-len(residuals):]
        mape = np.mean(np.abs(residuals / valid_series)) * 100 if (valid_series != 0).all() else np.nan
        
        accuracy_metrics.append({
            'Ticker': ticker,
            'Model': 'ARIMA(1,0,1)',
            'MAE': mae,
            'RMSE': rmse,
            'MAPE_%': mape,
            'AIC': arima_results[ticker]['aic'],
            'BIC': arima_results[ticker]['bic']
        })

if len(accuracy_metrics) > 0:
    accuracy_df = pd.DataFrame(accuracy_metrics)
    print(f"\n{accuracy_df.to_string(index=False)}")
else:
    print("No accuracy metrics to display")

# ============================================================================
# CELL 10: FORECAST SUMMARY TABLE
# ============================================================================
print("\n" + "=" * 60)
print("COMPREHENSIVE FORECAST SUMMARY")
print("=" * 60)

summary_data = []

for ticker in sorted(df['Ticker'].unique()):
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date')
    last_roa = ticker_data['ROA_TTM'].iloc[-1]
    
    arima_fcst = arima_results[ticker]['forecast'].iloc[0] if ticker in arima_results else np.nan
    panel_fcst = panel_forecasts[ticker][0] if ticker in panel_forecasts else np.nan
    
    summary_data.append({
        'Ticker': ticker,
        'Last_Observed_ROA': last_roa,
        'ARIMA_1Q_Forecast': arima_fcst,
        'PanelAR_1Q_Forecast': panel_fcst,
        'Avg_Forecast': np.nanmean([arima_fcst, panel_fcst])
    })

summary_df = pd.DataFrame(summary_data)
print(f"\n{summary_df.to_string(index=False)}")

# ============================================================================
# CELL 11: KEY INSIGHTS AND RECOMMENDATIONS
# ============================================================================
print("\n" + "=" * 60)
print("FORECAST ANALYSIS SUMMARY & RECOMMENDATIONS")
print("=" * 60)

print(f"""
KEY FINDINGS:

1. STATIONARITY:
   - Check stationarity_df output above for each stock's ROA_TTM series
   - Non-stationary series may need differencing in ARIMA models

2. FORECASTING APPROACHES USED:
   a) Individual ARIMA(1,0,1) Models:
      - Fit separately for each stock
      - Captures individual stock autocorrelation patterns
      - Best for: Stock-specific forecasts with uncertainty bounds
      
   b) Panel Autoregressive (AR) Model:
      - Pools information across all 5 stocks
      - Uses fixed effects for ticker-specific intercepts
      - Captures cross-sectional and temporal dynamics
      - Best for: Comparative analysis and overall trend

3. FORECAST HORIZON:
   - Forecasting 4 quarters (1 year) ahead
   - Suitable for quarterly panel data with 37 observations

4. MODEL SELECTION GUIDANCE:
   - Compare AIC/BIC values for ARIMA models
   - Review forecast accuracy metrics (RMSE, MAPE)
   - Panel AR useful for assessing relative performance across stocks

5. NEXT STEPS:
   - Monitor actual outcomes vs forecasts quarterly
   - Retrain models as new data becomes available
   - Consider alternative models if accuracy decreases
""")

print("=" * 60)
print("FORECAST ANALYSIS COMPLETE")
print("=" * 60)
```

**Key fixes made:**

1. **Line 49 (original error)**: Replaced `df[~np.isinf(df.select_dtypes(include=[np.number_])).any(axis=1)]` with a safer loop that checks each numeric column individually
2. **Added error handling** for stationarity tests and model fitting
3. **Safe division** for MAPE calculation to avoid division by zero
4. **Data validation** before plotting (check for sufficient data)
5. **Optional Panel AR model** - gracefully handles if it fails

Try running this fixed version - it should resolve the NumPy compatibility issue!

## @cecycantu24

I got this error, can you help me fix it?

## Copilot

The error occurs because the forecast data has a different length than expected. The issue is that when some stocks don't have ARIMA results or have different numbers of forecasts, the shapes don't match when plotting. Let me provide a fixed version of the visualization cell:

```python name=panel_forecast_analysis_fixed_viz.py
# ============================================================================
# CELL 8: FORECAST VISUALIZATION (FIXED)
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING FORECAST VISUALIZATION")
print("=" * 60)

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

tickers_list = sorted(df['Ticker'].unique())
forecast_periods_viz = 4

for idx, ticker in enumerate(tickers_list):
    ax = axes[idx]
    
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    
    # Historical data
    ax.plot(ticker_data.index, ticker_data['ROA_TTM'].values, 'b-o', label='Historical', linewidth=2, markersize=6)
    
    # Add ARIMA forecast if available
    if ticker in arima_results:
        try:
            hist_len = len(ticker_data)
            forecast_vals = arima_results[ticker]['forecast'].values
            forecast_ci = arima_results[ticker]['forecast_ci'].values
            
            # Ensure we have the right number of forecast periods
            n_forecast = len(forecast_vals)
            forecast_idx = np.arange(hist_len - 1, hist_len - 1 + n_forecast)
            
            # Plot forecast line
            ax.plot(forecast_idx, forecast_vals, 'r--s', label='ARIMA Forecast', linewidth=2, markersize=6)
            
            # Plot confidence interval
            if forecast_ci.shape[0] == len(forecast_vals):
                ax.fill_between(forecast_idx, forecast_ci[:, 0], forecast_ci[:, 1], alpha=0.2, color='red')
        except Exception as e:
            print(f"Warning: Could not plot ARIMA forecast for {ticker}: {str(e)}")
    
    # Add panel AR forecast if available
    if ticker in panel_forecasts:
        try:
            hist_len = len(ticker_data)
            panel_fcst = panel_forecasts[ticker]
            n_forecast = len(panel_fcst)
            forecast_idx = np.arange(hist_len - 1, hist_len - 1 + n_forecast)
            
            ax.plot(forecast_idx, panel_fcst, 'g--^', label='Panel AR Forecast', linewidth=2, markersize=6)
        except Exception as e:
            print(f"Warning: Could not plot Panel AR forecast for {ticker}: {str(e)}")
    
    ax.set_title(f'{ticker} - ROA_TTM Forecast', fontsize=12, fontweight='bold')
    ax.set_xlabel('Observation Index')
    ax.set_ylabel('ROA_TTM')
    ax.legend(loc='best', fontsize=9)
    ax.grid(True, alpha=0.3)

# Remove extra subplot if needed
if len(tickers_list) < 6:
    fig.delaxes(axes[5])

plt.tight_layout()
plt.savefig('forecast_comparison.png', dpi=300, bbox_inches='tight')
print("Plot saved as 'forecast_comparison.png'")
plt.show()

print("=" * 60)
print("VISUALIZATION COMPLETE")
print("=" * 60)
```

The key fixes are:

1. **Convert to numpy arrays explicitly** with `.values` to ensure proper data types
2. **Dynamically calculate forecast indices** based on actual forecast length instead of assuming `forecast_periods_viz`
3. **Add error handling** with try-except blocks for each forecast type
4. **Check array dimensions** before using `fill_between`
5. **Ensure shape compatibility** by verifying `forecast_ci.shape[0] == len(forecast_vals)`

**Alternative simpler approach** - If you want a more robust solution, you can also use this simpler version that creates separate plots for each stock:

```python name=simple_forecast_viz.py
# ============================================================================
# CELL 8B: SIMPLIFIED FORECAST VISUALIZATION
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING FORECAST VISUALIZATION")
print("=" * 60)

tickers_list = sorted(df['Ticker'].unique())

for ticker in tickers_list:
    fig, ax = plt.subplots(figsize=(12, 6))
    
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    
    # Historical data
    ax.plot(range(len(ticker_data)), ticker_data['ROA_TTM'].values, 'b-o', label='Historical', linewidth=2, markersize=6)
    
    # Add ARIMA forecast if available
    if ticker in arima_results:
        try:
            hist_len = len(ticker_data)
            forecast_vals = arima_results[ticker]['forecast'].values
            forecast_ci = arima_results[ticker]['forecast_ci'].values
            
            n_forecast = len(forecast_vals)
            forecast_idx = np.arange(hist_len - 1, hist_len - 1 + n_forecast)
            
            ax.plot(forecast_idx, forecast_vals, 'r--s', label='ARIMA Forecast', linewidth=2, markersize=6)
            ax.fill_between(forecast_idx, forecast_ci[:, 0], forecast_ci[:, 1], alpha=0.2, color='red', label='95% CI')
        except Exception as e:
            print(f"Warning: ARIMA forecast issue for {ticker}: {str(e)}")
    
    # Add panel AR forecast if available
    if ticker in panel_forecasts:
        try:
            hist_len = len(ticker_data)
            panel_fcst = panel_forecasts[ticker]
            n_forecast = len(panel_fcst)
            forecast_idx = np.arange(hist_len - 1, hist_len - 1 + n_forecast)
            
            ax.plot(forecast_idx, panel_fcst, 'g--^', label='Panel AR Forecast', linewidth=2, markersize=6)
        except Exception as e:
            print(f"Warning: Panel AR forecast issue for {ticker}: {str(e)}")
    
    ax.set_title(f'{ticker} - ROA_TTM Forecast', fontsize=13, fontweight='bold')
    ax.set_xlabel('Observation Index', fontsize=11)
    ax.set_ylabel('ROA_TTM', fontsize=11)
    ax.legend(loc='best', fontsize=10)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'forecast_{ticker}.png', dpi=300, bbox_inches='tight')
    print(f"Plot saved as 'forecast_{ticker}.png'")
    plt.show()

print("=" * 60)
print("VISUALIZATION COMPLETE - Individual plots for each stock")
print("=" * 60)
```

Try the first fixed version in your existing notebook. It maintains the 2x3 grid layout while properly handling different array shapes. Let me know if you encounter any other errors!
