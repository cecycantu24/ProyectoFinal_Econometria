# ============================================================================
# CELL 8: FORECAST VISUALIZATION (FIXED)
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING FORECAST VISUALIZATION")
print("=" * 60)

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

tickers_list = sorted(df['Ticker'].unique())
forecast_periods_viz = 4

for idx, ticker in enumerate(tickers_list):
    ax = axes[idx]
    
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    
    # Historical data
    ax.plot(ticker_data.index, ticker_data['ROA_TTM'].values, 'b-o', label='Historical', linewidth=2, markersize=6)
    
    # Add ARIMA forecast if available
    if ticker in arima_results:
        try:
            hist_len = len(ticker_data)
            forecast_vals = arima_results[ticker]['forecast'].values
            forecast_ci = arima_results[ticker]['forecast_ci'].values
            
            # Ensure we have the right number of forecast periods
            n_forecast = len(forecast_vals)
            forecast_idx = np.arange(hist_len - 1, hist_len - 1 + n_forecast)
            
            # Plot forecast line
            ax.plot(forecast_idx, forecast_vals, 'r--s', label='ARIMA Forecast', linewidth=2, markersize=6)
            
            # Plot confidence interval
            if forecast_ci.shape[0] == len(forecast_vals):
                ax.fill_between(forecast_idx, forecast_ci[:, 0], forecast_ci[:, 1], alpha=0.2, color='red')
        except Exception as e:
            print(f"Warning: Could not plot ARIMA forecast for {ticker}: {str(e)}")
    
    # Add panel AR forecast if available
    if ticker in panel_forecasts:
        try:
            hist_len = len(ticker_data)
            panel_fcst = panel_forecasts[ticker]
            n_forecast = len(panel_fcst)
            forecast_idx = np.arange(hist_len - 1, hist_len - 1 + n_forecast)
            
            ax.plot(forecast_idx, panel_fcst, 'g--^', label='Panel AR Forecast', linewidth=2, markersize=6)
        except Exception as e:
            print(f"Warning: Could not plot Panel AR forecast for {ticker}: {str(e)}")
    
    ax.set_title(f'{ticker} - ROA_TTM Forecast', fontsize=12, fontweight='bold')
    ax.set_xlabel('Observation Index')
    ax.set_ylabel('ROA_TTM')
    ax.legend(loc='best', fontsize=9)
    ax.grid(True, alpha=0.3)

# Remove extra subplot if needed
if len(tickers_list) < 6:
    fig.delaxes(axes[5])

plt.tight_layout()
plt.savefig('forecast_comparison.png', dpi=300, bbox_inches='tight')
print("Plot saved as 'forecast_comparison.png'")
plt.show()

print("=" * 60)
print("VISUALIZATION COMPLETE")
print("=" * 60)