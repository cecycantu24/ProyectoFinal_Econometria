# ============================================================================
# CELL 8B: SIMPLIFIED FORECAST VISUALIZATION
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING FORECAST VISUALIZATION")
print("=" * 60)

tickers_list = sorted(df['Ticker'].unique())

for ticker in tickers_list:
    fig, ax = plt.subplots(figsize=(12, 6))
    
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    
    # Historical data
    ax.plot(range(len(ticker_data)), ticker_data['ROA_TTM'].values, 'b-o', label='Historical', linewidth=2, markersize=6)
    
    # Add ARIMA forecast if available
    if ticker in arima_results:
        try:
            hist_len = len(ticker_data)
            forecast_vals = arima_results[ticker]['forecast'].values
            forecast_ci = arima_results[ticker]['forecast_ci'].values
            
            n_forecast = len(forecast_vals)
            forecast_idx = np.arange(hist_len - 1, hist_len - 1 + n_forecast)
            
            ax.plot(forecast_idx, forecast_vals, 'r--s', label='ARIMA Forecast', linewidth=2, markersize=6)
            ax.fill_between(forecast_idx, forecast_ci[:, 0], forecast_ci[:, 1], alpha=0.2, color='red', label='95% CI')
        except Exception as e:
            print(f"Warning: ARIMA forecast issue for {ticker}: {str(e)}")
    
    # Add panel AR forecast if available
    if ticker in panel_forecasts:
        try:
            hist_len = len(ticker_data)
            panel_fcst = panel_forecasts[ticker]
            n_forecast = len(panel_fcst)
            forecast_idx = np.arange(hist_len - 1, hist_len - 1 + n_forecast)
            
            ax.plot(forecast_idx, panel_fcst, 'g--^', label='Panel AR Forecast', linewidth=2, markersize=6)
        except Exception as e:
            print(f"Warning: Panel AR forecast issue for {ticker}: {str(e)}")
    
    ax.set_title(f'{ticker} - ROA_TTM Forecast', fontsize=13, fontweight='bold')
    ax.set_xlabel('Observation Index', fontsize=11)
    ax.set_ylabel('ROA_TTM', fontsize=11)
    ax.legend(loc='best', fontsize=10)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f'forecast_{ticker}.png', dpi=300, bbox_inches='tight')
    print(f"Plot saved as 'forecast_{ticker}.png'")
    plt.show()

print("=" * 60)
print("VISUALIZATION COMPLETE - Individual plots for each stock")
print("=" * 60)