# ============================================================================
# CELL 1: SETUP AND INSTALLATION
# ============================================================================
# Install required packages
!pip install linearmodels statsmodels pmdarima openpyxl -q

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.formula.api import ols
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

print("=" * 60)
print("FORECAST ANALYSIS SETUP COMPLETE")
print("=" * 60)

# ============================================================================
# CELL 2: LOAD AND PREPARE DATA
# ============================================================================
print("\n" + "=" * 60)
print("LOADING AND PREPARING DATA")
print("=" * 60)

# Load data
df = pd.read_excel('/content/datapanel_data.xlsx')

# Parse Date with dayfirst=True
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)

# Sort by Ticker and Date
df = df.sort_values(['Ticker', 'Date']).reset_index(drop=True)

# Create engineered features
df['GrossMargin'] = df['GrossProfit'] / df['Revenue']
df['OperatingMargin'] = df['OperatingProfit'] / df['Revenue']
df['EBITDAMargin'] = df['EBITDA'] / df['Revenue']
df['AssetTurnover'] = df['Revenue'] / df['TotalAssets']
df['LogRevenue'] = np.log(df['Revenue'])
df['LogAssets'] = np.log(df['TotalAssets'])

# Drop NaN and infinite values
df = df.dropna()
df = df[~np.isinf(df.select_dtypes(include=[np.number_])).any(axis=1)]

print(f"Data shape: {df.shape}")
print(f"Stocks: {df['Ticker'].unique()}")
print(f"Date range: {df['Date'].min()} to {df['Date'].max()}")
print(f"Observations per stock: {df.groupby('Ticker').size().values}")

# ============================================================================
# CELL 3: STATIONARITY TESTING
# ============================================================================
print("\n" + "=" * 60)
print("STATIONARITY TESTS (ADF and KPSS)")
print("=" * 60)

forecast_vars = ['ROA_TTM', 'ROE_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin']

stationarity_results = []

for ticker in df['Ticker'].unique():
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    
    print(f"\n{'-' * 60}")
    print(f"Ticker: {ticker}")
    print(f"{'-' * 60}")
    
    for var in forecast_vars:
        series = ticker_data[var].dropna()
        
        # ADF Test
        adf_result = adfuller(series, autolag='AIC')
        adf_pvalue = adf_result[1]
        
        # KPSS Test
        kpss_result = kpss(series, regression='c', nlags='auto')
        kpss_pvalue = kpss_result[1]
        
        # Determine stationarity
        is_stationary = (adf_pvalue < 0.05) and (kpss_pvalue >= 0.05)
        
        stationarity_results.append({
            'Ticker': ticker,
            'Variable': var,
            'ADF_pvalue': adf_pvalue,
            'KPSS_pvalue': kpss_pvalue,
            'Stationary': is_stationary
        })
        
        print(f"  {var}:")
        print(f"    ADF p-value: {adf_pvalue:.4f} {'✓ Stationary' if adf_pvalue < 0.05 else '✗ Non-stationary'}")
        print(f"    KPSS p-value: {kpss_pvalue:.4f} {'✓ Stationary' if kpss_pvalue >= 0.05 else '✗ Non-stationary'}")

stationarity_df = pd.DataFrame(stationarity_results)
print("\n" + "=" * 60)
print("STATIONARITY SUMMARY TABLE")
print("=" * 60)
print(stationarity_df.to_string(index=False))

# ============================================================================
# CELL 4: ACF/PACF PLOTS FOR AUTOCORRELATION ANALYSIS
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING ACF/PACF PLOTS")
print("=" * 60)

fig, axes = plt.subplots(5, 2, figsize=(14, 16))

tickers = df['Ticker'].unique()

for idx, ticker in enumerate(tickers):
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    series = ticker_data['ROA_TTM'].dropna()
    
    # ACF
    plot_acf(series, lags=10, ax=axes[idx, 0], title=f'{ticker} - ROA_TTM ACF')
    
    # PACF
    plot_pacf(series, lags=10, ax=axes[idx, 1], title=f'{ticker} - ROA_TTM PACF')

plt.tight_layout()
plt.savefig('acf_pacf_plots.png', dpi=300, bbox_inches='tight')
print("Plot saved as 'acf_pacf_plots.png'")
plt.show()

# ============================================================================
# CELL 5: INDIVIDUAL ARIMA MODELS FOR EACH STOCK
# ============================================================================
print("\n" + "=" * 60)
print("INDIVIDUAL ARIMA FORECASTS FOR EACH STOCK (ROA_TTM)")
print("=" * 60)

arima_results = {}
forecast_periods = 4  # 4 quarters ahead

for ticker in df['Ticker'].unique():
    print(f"\n{'-' * 60}")
    print(f"Ticker: {ticker}")
    print(f"{'-' * 60}")
    
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    series = ticker_data['ROA_TTM'].dropna()
    
    try:
        # Fit ARIMA(1,0,1) - simple model suitable for short panel
        model = ARIMA(series, order=(1, 0, 1))
        arima_fit = model.fit()
        
        print(f"\nARIMA(1,0,1) Model Summary:")
        print(arima_fit.summary())
        
        # Forecast 4 quarters ahead
        forecast = arima_fit.get_forecast(steps=forecast_periods)
        forecast_values = forecast.predicted_mean
        forecast_ci = forecast.conf_int()
        
        print(f"\nForecast for {ticker} (4 quarters ahead):")
        forecast_table = pd.DataFrame({
            'Period': range(1, forecast_periods + 1),
            'Forecast': forecast_values.values,
            'Lower_CI': forecast_ci.iloc[:, 0].values,
            'Upper_CI': forecast_ci.iloc[:, 1].values
        })
        print(forecast_table.to_string(index=False))
        
        arima_results[ticker] = {
            'model': arima_fit,
            'forecast': forecast_values,
            'forecast_ci': forecast_ci,
            'aic': arima_fit.aic,
            'bic': arima_fit.bic,
            'rmse': np.sqrt(arima_fit.mse)
        }
        
    except Exception as e:
        print(f"Error fitting ARIMA for {ticker}: {str(e)}")

# ============================================================================
# CELL 6: PANEL AUTOREGRESSIVE (PANEL AR) FORECAST
# ============================================================================
print("\n" + "=" * 60)
print("PANEL AUTOREGRESSIVE (AR) FORECAST")
print("=" * 60)

# Create lagged variables for panel AR model
df_ar = df[['Ticker', 'Date', 'ROA_TTM', 'ROE_TTM']].copy().sort_values(['Ticker', 'Date'])

for lag in [1, 2]:
    df_ar[f'ROA_TTM_lag{lag}'] = df_ar.groupby('Ticker')['ROA_TTM'].shift(lag)
    df_ar[f'ROE_TTM_lag{lag}'] = df_ar.groupby('Ticker')['ROE_TTM'].shift(lag)

df_ar = df_ar.dropna()

print(f"Panel AR dataset shape: {df_ar.shape}")

# Fit Panel AR model with fixed effects
formula_panel_ar = 'ROA_TTM ~ ROA_TTM_lag1 + ROA_TTM_lag2 + ROE_TTM_lag1 + C(Ticker)'
panel_ar_model = ols(formula_panel_ar, data=df_ar).fit(cov_type='HC1')

print(f"\n{panel_ar_model.summary()}")

panel_ar_coef = panel_ar_model.params
print(f"\nPanel AR Coefficients:")
print(panel_ar_coef)

# ============================================================================
# CELL 7: PANEL-LEVEL FORECASTS FROM PANEL AR
# ============================================================================
print("\n" + "=" * 60)
print("PANEL-LEVEL FORECASTS FROM PANEL AR MODEL")
print("=" * 60)

# Get last observations for each stock
last_obs = df_ar.groupby('Ticker').tail(2).reset_index(drop=True)

panel_forecasts = {}
forecast_horizon = 4

for ticker in df['Ticker'].unique():
    ticker_last = last_obs[last_obs['Ticker'] == ticker]
    
    if len(ticker_last) >= 2:
        roa_t = ticker_last['ROA_TTM'].iloc[-1]
        roa_t_lag1 = ticker_last['ROA_TTM'].iloc[-2]
        roe_t = ticker_last['ROE_TTM'].iloc[-1]
        roe_t_lag1 = ticker_last['ROE_TTM'].iloc[-2]
        
        # Get fixed effect for ticker
        ticker_coef = panel_ar_model.params[f'C(Ticker)[T.{ticker}]'] if f'C(Ticker)[T.{ticker}]' in panel_ar_model.params else 0
        intercept = panel_ar_model.params['Intercept']
        
        forecasts_list = []
        current_roa = roa_t
        prev_roa = roa_t_lag1
        
        for h in range(1, forecast_horizon + 1):
            # Simple AR(1) forecast using panel coefficients
            coef_lag1 = panel_ar_model.params.get('ROA_TTM_lag1', 0)
            coef_lag2 = panel_ar_model.params.get('ROA_TTM_lag2', 0)
            
            forecast_val = intercept + ticker_coef + coef_lag1 * current_roa + coef_lag2 * prev_roa
            forecasts_list.append(forecast_val)
            
            # Update lags for next period
            prev_roa = current_roa
            current_roa = forecast_val
        
        panel_forecasts[ticker] = forecasts_list
        
        print(f"\n{ticker} - Panel AR Forecast (4 quarters ahead):")
        forecast_df = pd.DataFrame({
            'Quarter': range(1, forecast_horizon + 1),
            'Forecast': forecasts_list
        })
        print(forecast_df.to_string(index=False))

# ============================================================================
# CELL 8: FORECAST VISUALIZATION
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING FORECAST VISUALIZATION")
print("=" * 60)

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

tickers_list = sorted(df['Ticker'].unique())
forecast_periods_viz = 4

for idx, ticker in enumerate(tickers_list):
    ax = axes[idx]
    
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    
    # Historical data
    ax.plot(ticker_data.index, ticker_data['ROA_TTM'], 'b-o', label='Historical', linewidth=2, markersize=6)
    
    # Add ARIMA forecast if available
    if ticker in arima_results:
        hist_len = len(ticker_data)
        forecast_idx = np.arange(hist_len - 1, hist_len + forecast_periods_viz)
        forecast_vals = arima_results[ticker]['forecast'].values
        forecast_ci = arima_results[ticker]['forecast_ci'].values
        
        ax.plot(forecast_idx, forecast_vals, 'r--s', label='ARIMA Forecast', linewidth=2, markersize=6)
        ax.fill_between(forecast_idx, forecast_ci[:, 0], forecast_ci[:, 1], alpha=0.2, color='red')
    
    # Add panel AR forecast if available
    if ticker in panel_forecasts:
        hist_len = len(ticker_data)
        forecast_idx = np.arange(hist_len - 1, hist_len + forecast_periods_viz)
        ax.plot(forecast_idx, panel_forecasts[ticker], 'g--^', label='Panel AR Forecast', linewidth=2, markersize=6)
    
    ax.set_title(f'{ticker} - ROA_TTM Forecast', fontsize=12, fontweight='bold')
    ax.set_xlabel('Observation Index')
    ax.set_ylabel('ROA_TTM')
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)

# Remove extra subplot
fig.delaxes(axes[5])

plt.tight_layout()
plt.savefig('forecast_comparison.png', dpi=300, bbox_inches='tight')
print("Plot saved as 'forecast_comparison.png'")
plt.show()

# ============================================================================
# CELL 9: FORECAST ACCURACY METRICS (IN-SAMPLE)
# ============================================================================
print("\n" + "=" * 60)
print("FORECAST ACCURACY METRICS (IN-SAMPLE)")
print("=" * 60)

accuracy_metrics = []

for ticker in df['Ticker'].unique():
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date').reset_index(drop=True)
    series = ticker_data['ROA_TTM'].dropna()
    
    if ticker in arima_results:
        arima_model = arima_results[ticker]['model']
        fitted_values = arima_model.fittedvalues
        residuals = arima_model.resid
        
        # Calculate metrics
        mae = np.mean(np.abs(residuals))
        rmse = np.sqrt(np.mean(residuals**2))
        mape = np.mean(np.abs(residuals / series[len(series)-len(residuals):]))
        
        accuracy_metrics.append({
            'Ticker': ticker,
            'Model': 'ARIMA(1,0,1)',
            'MAE': mae,
            'RMSE': rmse,
            'MAPE': mape,
            'AIC': arima_results[ticker]['aic'],
            'BIC': arima_results[ticker]['bic']
        })

accuracy_df = pd.DataFrame(accuracy_metrics)
print(f"\n{accuracy_df.to_string(index=False)}")

# ============================================================================
# CELL 10: FORECAST SUMMARY TABLE
# ============================================================================
print("\n" + "=" * 60)
print("COMPREHENSIVE FORECAST SUMMARY")
print("=" * 60)

summary_data = []

for ticker in sorted(df['Ticker'].unique()):
    ticker_data = df[df['Ticker'] == ticker].sort_values('Date')
    last_roa = ticker_data['ROA_TTM'].iloc[-1]
    
    arima_fcst = arima_results[ticker]['forecast'].iloc[0] if ticker in arima_results else np.nan
    panel_fcst = panel_forecasts[ticker][0] if ticker in panel_forecasts else np.nan
    
    summary_data.append({
        'Ticker': ticker,
        'Last_Observed_ROA': last_roa,
        'ARIMA_1Q_Forecast': arima_fcst,
        'PanelAR_1Q_Forecast': panel_fcst,
        'Avg_Forecast': np.nanmean([arima_fcst, panel_fcst])
    })

summary_df = pd.DataFrame(summary_data)
print(f"\n{summary_df.to_string(index=False)}")

# ============================================================================
# CELL 11: KEY INSIGHTS AND RECOMMENDATIONS
# ============================================================================
print("\n" + "=" * 60)
print("FORECAST ANALYSIS SUMMARY & RECOMMENDATIONS")
print("=" * 60)

print(f"""
KEY FINDINGS:

1. STATIONARITY:
   - Check stationarity_df output above for each stock's ROA_TTM series
   - Non-stationary series may need differencing in ARIMA models

2. FORECASTING APPROACHES USED:
   a) Individual ARIMA(1,0,1) Models:
      - Fit separately for each stock
      - Captures individual stock autocorrelation patterns
      - Best for: Stock-specific forecasts with uncertainty bounds
      
   b) Panel Autoregressive (AR) Model:
      - Pools information across all 5 stocks
      - Uses fixed effects for ticker-specific intercepts
      - Captures cross-sectional and temporal dynamics
      - Best for: Comparative analysis and overall trend

3. FORECAST HORIZON:
   - Forecasting 4 quarters (1 year) ahead
   - Suitable for quarterly panel data with 37 observations

4. MODEL SELECTION GUIDANCE:
   - Compare AIC/BIC values for ARIMA models
   - Review forecast accuracy metrics (RMSE, MAPE)
   - Panel AR useful for assessing relative performance across stocks

5. NEXT STEPS:
   - Monitor actual outcomes vs forecasts quarterly
   - Retrain models as new data becomes available
   - Consider alternative models if accuracy decreases
""")

print("=" * 60)
print("FORECAST ANALYSIS COMPLETE")
print("=" * 60)