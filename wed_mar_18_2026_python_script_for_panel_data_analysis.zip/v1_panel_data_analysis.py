# ============================================================================
# CELL 1: SETUP AND INSTALLATION
# ============================================================================
# Install required packages
!pip install linearmodels openpyxl -q

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.formula.api import ols
from statsmodels.stats.outliers_influence import variance_inflation_factor
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

print("=" * 60)
print("SETUP COMPLETE: All packages installed and imported")
print("=" * 60)

# ============================================================================
# CELL 2: DATA LOADING AND PREPARATION
# ============================================================================
# Load the Excel file
df = pd.read_excel('/content/datapanel_data.xlsx')

print("=" * 60)
print("DATA LOADED: Raw Data Summary")
print("=" * 60)
print(f"Shape: {df.shape}")
print(f"Columns: {df.columns.tolist()}")
print(f"\nFirst few rows:\n{df.head()}")
print(f"\nData types:\n{df.dtypes}")
print(f"\nMissing values:\n{df.isnull().sum()}")

# Parse Date with dayfirst=True
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)

# Sort by Ticker and Date for panel structure
df = df.sort_values(['Ticker', 'Date']).reset_index(drop=True)

print(f"\nAfter Date parsing - Observations per Ticker:")
print(df.groupby('Ticker').size())

# ============================================================================
# CELL 3: FEATURE ENGINEERING
# ============================================================================
print("\n" + "=" * 60)
print("FEATURE ENGINEERING")
print("=" * 60)

# Create engineered features
df['GrossMargin'] = df['GrossProfit'] / df['Revenue']
df['OperatingMargin'] = df['OperatingProfit'] / df['Revenue']
df['EBITDAMargin'] = df['EBITDA'] / df['Revenue']
df['AssetTurnover'] = df['Revenue'] / df['TotalAssets']
df['LogRevenue'] = np.log(df['Revenue'])
df['LogAssets'] = np.log(df['TotalAssets'])

print("Features created:")
print("- GrossMargin = GrossProfit / Revenue")
print("- OperatingMargin = OperatingProfit / Revenue")
print("- EBITDAMargin = EBITDA / Revenue")
print("- AssetTurnover = Revenue / TotalAssets")
print("- LogRevenue = ln(Revenue)")
print("- LogAssets = ln(TotalAssets)")

# Drop NaN and infinite values
initial_rows = len(df)
df = df.dropna()
df = df[~np.isinf(df.select_dtypes(include=[np.number_])).any(axis=1)]
final_rows = len(df)

print(f"\nRows removed: {initial_rows - final_rows}")
print(f"Final sample size: {final_rows}")
print(f"\nFinal data summary:\n{df.describe()}")

# ============================================================================
# CELL 4: POOLED OLS REGRESSION
# ============================================================================
print("\n" + "=" * 60)
print("MODEL 1: POOLED OLS REGRESSION")
print("=" * 60)

formula = 'ROA_TTM ~ GrossMargin + OperatingMargin + EBITDAMargin + AssetTurnover + LogRevenue + LogAssets'

# Pooled OLS
pooled_model = ols(formula, data=df).fit(cov_type='HC1')

print(f"\n{pooled_model.summary()}")
print(f"\nNumber of observations: {pooled_model.nobs}")
print(f"R-squared: {pooled_model.rsquared:.4f}")
print(f"Adjusted R-squared: {pooled_model.rsquared_adj:.4f}")

pooled_coef = pooled_model.params.copy()
pooled_se = pooled_model.bse.copy()
pooled_r2 = pooled_model.rsquared
pooled_adj_r2 = pooled_model.rsquared_adj
pooled_nobs = pooled_model.nobs

# ============================================================================
# CELL 5: FIXED EFFECTS REGRESSION
# ============================================================================
print("\n" + "=" * 60)
print("MODEL 2: FIXED EFFECTS REGRESSION")
print("=" * 60)

formula_fe = 'ROA_TTM ~ GrossMargin + OperatingMargin + EBITDAMargin + AssetTurnover + LogRevenue + LogAssets + C(Ticker)'

fe_model = ols(formula_fe, data=df).fit(cov_type='HC1')

print(f"\n{fe_model.summary()}")
print(f"\nNumber of observations: {fe_model.nobs}")
print(f"R-squared: {fe_model.rsquared:.4f}")
print(f"Adjusted R-squared: {fe_model.rsquared_adj:.4f}")

fe_coef = fe_model.params[:-4].copy()  # Exclude dummy coefficients
fe_se = fe_model.bse[:-4].copy()
fe_r2 = fe_model.rsquared
fe_adj_r2 = fe_model.rsquared_adj
fe_nobs = fe_model.nobs
fe_residuals = fe_model.resid

# Store FE results for Hausman test
fe_model_full = fe_model

# ============================================================================
# CELL 6: RANDOM EFFECTS - MANUAL GLS QUASI-DEMEANING
# ============================================================================
print("\n" + "=" * 60)
print("MODEL 3: RANDOM EFFECTS - GLS QUASI-DEMEANING")
print("=" * 60)

# Prepare data for RE estimation
df_re = df[['Ticker', 'ROA_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin', 'AssetTurnover', 'LogRevenue', 'LogAssets']].copy()
df_re = df_re.dropna()

# Extract parameters
T = df_re.groupby('Ticker').size().mean()
N = df_re['Ticker'].nunique()
print(f"Number of groups (N): {N}")
print(f"Average time periods (T): {T}")

# Step 1: Estimate sigma2_e from FE residuals
sigma2_e = fe_model.mse_resid
print(f"\nSigma2_e (from FE residuals): {sigma2_e:.6f}")

# Step 2: Estimate sigma2_u from between-effects regression
group_means = df_re.groupby('Ticker')[['ROA_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin', 'AssetTurnover', 'LogRevenue', 'LogAssets']].mean()
be_model = ols('ROA_TTM ~ GrossMargin + OperatingMargin + EBITDAMargin + AssetTurnover + LogRevenue + LogAssets', data=group_means).fit()
sigma2_u = max((be_model.mse_resid - sigma2_e / T), 0)
print(f"Sigma2_u (from between effects): {sigma2_u:.6f}")

# Step 3: Compute theta for quasi-demeaning
theta = 1 - np.sqrt(sigma2_e / (sigma2_e + T * sigma2_u)) if (sigma2_e + T * sigma2_u) > 0 else 0
print(f"Theta (quasi-demeaning parameter): {theta:.6f}")

# Step 4: Create quasi-demeaned variables
df_re['group_idx'] = pd.Categorical(df_re['Ticker']).codes
group_means_dict = df_re.groupby('group_idx')[['ROA_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin', 'AssetTurnover', 'LogRevenue', 'LogAssets']].mean()

df_re['ROA_TTM_qd'] = df_re.apply(lambda row: row['ROA_TTM'] - theta * (row['ROA_TTM'] - group_means_dict.loc[row['group_idx'], 'ROA_TTM']), axis=1)
df_re['GrossMargin_qd'] = df_re.apply(lambda row: row['GrossMargin'] - theta * (row['GrossMargin'] - group_means_dict.loc[row['group_idx'], 'GrossMargin']), axis=1)
df_re['OperatingMargin_qd'] = df_re.apply(lambda row: row['OperatingMargin'] - theta * (row['OperatingMargin'] - group_means_dict.loc[row['group_idx'], 'OperatingMargin']), axis=1)
df_re['EBITDAMargin_qd'] = df_re.apply(lambda row: row['EBITDAMargin'] - theta * (row['EBITDAMargin'] - group_means_dict.loc[row['group_idx'], 'EBITDAMargin']), axis=1)
df_re['AssetTurnover_qd'] = df_re.apply(lambda row: row['AssetTurnover'] - theta * (row['AssetTurnover'] - group_means_dict.loc[row['group_idx'], 'AssetTurnover']), axis=1)
df_re['LogRevenue_qd'] = df_re.apply(lambda row: row['LogRevenue'] - theta * (row['LogRevenue'] - group_means_dict.loc[row['group_idx'], 'LogRevenue']), axis=1)
df_re['LogAssets_qd'] = df_re.apply(lambda row: row['LogAssets'] - theta * (row['LogAssets'] - group_means_dict.loc[row['group_idx'], 'LogAssets']), axis=1)

# Step 5: Run OLS on quasi-demeaned data with HC1 errors
formula_re = 'ROA_TTM_qd ~ GrossMargin_qd + OperatingMargin_qd + EBITDAMargin_qd + AssetTurnover_qd + LogRevenue_qd + LogAssets_qd - 1'
re_model = ols(formula_re, data=df_re).fit(cov_type='HC1')

print(f"\n{re_model.summary()}")
print(f"\nNumber of observations: {re_model.nobs}")
print(f"R-squared: {re_model.rsquared:.4f}")
print(f"Adjusted R-squared: {re_model.rsquared_adj:.4f}")

re_coef = re_model.params.copy()
re_se = re_model.bse.copy()
re_r2 = re_model.rsquared
re_adj_r2 = re_model.rsquared_adj
re_nobs = re_model.nobs
re_residuals = re_model.resid

# ============================================================================
# CELL 7: HAUSMAN TEST - FE vs RE
# ============================================================================
print("\n" + "=" * 60)
print("HAUSMAN TEST: FIXED EFFECTS vs RANDOM EFFECTS")
print("=" * 60)

# Extract coefficients (excluding constant and dummies for consistency)
fe_coef_test = fe_model_full.params[:-4].values  # FE slope coefficients
re_coef_test = re_model.params.values  # RE slope coefficients

# Variance-covariance matrices
var_fe = fe_model_full.cov_params().iloc[:-4, :-4].values
var_re = re_model.cov_params().values

# Hausman statistic: H = (b_fe - b_re)' * [Var(b_fe) - Var(b_re)]^(-1) * (b_fe - b_re)
diff_coef = fe_coef_test - re_coef_test
var_diff = var_fe - var_re

# Use pseudoinverse to handle potential singularity
var_diff_inv = np.linalg.pinv(var_diff)
hausman_stat = diff_coef.T @ var_diff_inv @ diff_coef

# Degrees of freedom = number of slope coefficients
df_test = len(fe_coef_test)

# P-value from chi-squared distribution
p_value = 1 - stats.chi2.cdf(hausman_stat, df_test)

print(f"\nHausman Test Results:")
print(f"  Chi-squared statistic: {hausman_stat:.4f}")
print(f"  Degrees of freedom: {df_test}")
print(f"  P-value: {p_value:.4f}")

if p_value < 0.05:
    print(f"\n  CONCLUSION: Reject H0 (p = {p_value:.4f} < 0.05)")
    print(f"  --> Use FIXED EFFECTS model (FE preferred over RE)")
else:
    print(f"\n  CONCLUSION: Fail to reject H0 (p = {p_value:.4f} >= 0.05)")
    print(f"  --> Use RANDOM EFFECTS model (RE is appropriate)")

# ============================================================================
# CELL 8: MODEL COMPARISON TABLE
# ============================================================================
print("\n" + "=" * 60)
print("MODEL COMPARISON TABLE")
print("=" * 60)

# Create comparison dataframe
comparison_data = {
    'Pooled OLS': pooled_coef,
    'Fixed Effects': fe_coef,
    'Random Effects': re_coef
}

comparison_df = pd.DataFrame(comparison_data)
comparison_df['Variable'] = comparison_df.index
comparison_df = comparison_df[['Variable', 'Pooled OLS', 'Fixed Effects', 'Random Effects']]

print(f"\n{comparison_df.to_string(index=False)}")

# Add standard errors
print("\n" + "-" * 60)
print("Standard Errors (HC1 Robust):")
print("-" * 60)

se_data = {
    'Pooled OLS': pooled_se,
    'Fixed Effects': fe_se,
    'Random Effects': re_se
}

se_df = pd.DataFrame(se_data)
se_df['Variable'] = se_df.index
se_df = se_df[['Variable', 'Pooled OLS', 'Fixed Effects', 'Random Effects']]

print(f"\n{se_df.to_string(index=False)}")

# Fit statistics
print("\n" + "-" * 60)
print("Model Fit Statistics:")
print("-" * 60)

fit_stats = pd.DataFrame({
    'Statistic': ['R-squared', 'Adj. R-squared', 'N Observations'],
    'Pooled OLS': [f"{pooled_r2:.4f}", f"{pooled_adj_r2:.4f}", f"{pooled_nobs}"],
    'Fixed Effects': [f"{fe_r2:.4f}", f"{fe_adj_r2:.4f}", f"{fe_nobs}"],
    'Random Effects': [f"{re_r2:.4f}", f"{re_adj_r2:.4f}", f"{re_nobs}"]
})

print(f"\n{fit_stats.to_string(index=False)}")

# ============================================================================
# CELL 9: COEFFICIENT PLOT WITH ERROR BARS
# ============================================================================
print("\n" + "=" * 60)
print("GENERATING COEFFICIENT PLOT")
print("=" * 60)

# Prepare data for plotting
variables = pooled_coef.index
n_vars = len(variables)

# Create figure with 3 subplots
fig, axes = plt.subplots(1, 3, figsize=(18, 6), sharey=True)

models = ['Pooled OLS', 'Fixed Effects', 'Random Effects']
coef_list = [pooled_coef, fe_coef, re_coef]
se_list = [pooled_se, fe_se, re_se]

for idx, (ax, model, coef, se) in enumerate(zip(axes, models, coef_list, se_list)):
    # Align indices for SE
    se_aligned = se[coef.index]
    
    # Create color array (green for positive, red for negative)
    colors = ['green' if x > 0 else 'red' for x in coef.values]
    
    # Plot horizontal bars with error bars
    y_pos = np.arange(len(coef))
    ax.barh(y_pos, coef.values, xerr=se_aligned.values, color=colors, alpha=0.7, capsize=5, ecolor='black')
    
    # Add vertical line at x=0
    ax.axvline(x=0, color='black', linestyle='--', linewidth=0.8, alpha=0.5)
    
    # Formatting
    ax.set_yticks(y_pos)
    ax.set_yticklabels(coef.index, fontsize=10)
    ax.set_xlabel('Coefficient Value', fontsize=11, fontweight='bold')
    ax.set_title(f'{model}', fontsize=12, fontweight='bold')
    ax.grid(axis='x', alpha=0.3)

plt.tight_layout()
plt.savefig('panel_coefficients.png', dpi=300, bbox_inches='tight')
print(f"\nPlot saved as 'panel_coefficients.png'")
plt.show()

# ============================================================================
# CELL 10: DESCRIPTIVE STATISTICS BY TICKER
# ============================================================================
print("\n" + "=" * 60)
print("DESCRIPTIVE STATISTICS BY TICKER")
print("=" * 60)

# Select variables for descriptive statistics
desc_vars = ['ROA_TTM', 'ROE_TTM', 'GrossMargin', 'OperatingMargin', 'EBITDAMargin']

# Create descriptive statistics table grouped by Ticker
desc_stats = df.groupby('Ticker')[desc_vars].agg(['mean', 'std', 'min', 'max', 'count'])

print(f"\n{desc_stats}")

# Summary across all tickers
print("\n" + "-" * 60)
print("Overall Summary Statistics (All Tickers):")
print("-" * 60)
overall_stats = df[desc_vars].describe()
print(f"\n{overall_stats}")

print("\n" + "=" * 60)
print("ANALYSIS COMPLETE")
print("=" * 60)